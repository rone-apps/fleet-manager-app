"use client";

import React, { useState } from "react";
import { Box, Tabs, Tab } from "@mui/material";
import {
  AttachMoney,
  Autorenew,
  MoneyOff,
} from "@mui/icons-material";

// Import expense sub-components
import LeaseExpenseTab from "./expense/LeaseExpenseTab";
import FixedExpensesTab from "./expense/FixedExpensesTab";
import OtherExpensesTab from "./expense/OtherExpensesTab";

export default function ExpenseTab({ driverNumber, startDate, endDate }) {
  const [activeSubTab, setActiveSubTab] = useState(0);

  const handleSubTabChange = (event, newValue) => {
    setActiveSubTab(newValue);
  };

  return (
    <Box>
      <Tabs
        value={activeSubTab}
        onChange={handleSubTabChange}
        sx={{ borderBottom: 1, borderColor: "divider", mb: 3 }}
      >
        <Tab icon={<AttachMoney />} iconPosition="start" label="Lease Expense" />
        <Tab icon={<Autorenew />} iconPosition="start" label="Fixed Expenses" />
        <Tab icon={<MoneyOff />} iconPosition="start" label="Other Expenses" />
      </Tabs>

      {activeSubTab === 0 && (
        <LeaseExpenseTab
          driverNumber={driverNumber}
          startDate={startDate}
          endDate={endDate}
        />
      )}
      {activeSubTab === 1 && (
        <FixedExpensesTab
          driverNumber={driverNumber}
          startDate={startDate}
          endDate={endDate}
        />
      )}
      {activeSubTab === 2 && (
        <OtherExpensesTab
          driverNumber={driverNumber}
          startDate={startDate}
          endDate={endDate}
        />
      )}
    </Box>
  );
}
