"use client";

import React, { useState } from "react";
import { Box, Tabs, Tab } from "@mui/material";
import {
  AttachMoney,
  CreditCard,
  Receipt,
  TrendingUp,
} from "@mui/icons-material";

// Import revenue sub-components
import LeaseRevenueTab from "./revenue/LeaseRevenueTab";
import CreditCardsTab from "./revenue/CreditCardsTab";
import ChargesTab from "./revenue/ChargesTab";
import OtherRevenueTab from "./revenue/OtherRevenueTab";

export default function RevenueTab({ driverNumber, startDate, endDate }) {
  const [activeSubTab, setActiveSubTab] = useState(0);

  const handleSubTabChange = (event, newValue) => {
    setActiveSubTab(newValue);
  };

  return (
    <Box>
      <Tabs
        value={activeSubTab}
        onChange={handleSubTabChange}
        sx={{ borderBottom: 1, borderColor: "divider", mb: 3 }}
      >
        <Tab icon={<AttachMoney />} iconPosition="start" label="Lease Revenue" />
        <Tab icon={<CreditCard />} iconPosition="start" label="Credit Cards" />
        <Tab icon={<Receipt />} iconPosition="start" label="Charges" />
        <Tab icon={<TrendingUp />} iconPosition="start" label="Other Revenue" />
      </Tabs>

      {activeSubTab === 0 && (
        <LeaseRevenueTab
          driverNumber={driverNumber}
          startDate={startDate}
          endDate={endDate}
        />
      )}
      {activeSubTab === 1 && (
        <CreditCardsTab
          driverNumber={driverNumber}
          startDate={startDate}
          endDate={endDate}
        />
      )}
      {activeSubTab === 2 && (
        <ChargesTab
          driverNumber={driverNumber}
          startDate={startDate}
          endDate={endDate}
        />
      )}
      {activeSubTab === 3 && (
        <OtherRevenueTab
          driverNumber={driverNumber}
          startDate={startDate}
          endDate={endDate}
        />
      )}
    </Box>
  );
}
