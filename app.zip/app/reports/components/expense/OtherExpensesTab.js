"use client";

import React from "react";
import { Box, Typography, Paper } from "@mui/material";
import { MoneyOff } from "@mui/icons-material";

export default function OtherExpensesTab({ driverNumber, startDate, endDate }) {
  return (
    <Paper sx={{ p: 6, textAlign: "center" }}>
      <MoneyOff sx={{ fontSize: 80, color: "text.disabled", mb: 2 }} />
      <Typography variant="h6" color="text.secondary" gutterBottom>
        Other Expenses Tracking
      </Typography>
      <Typography variant="body2" color="text.secondary">
        This feature will track one-time expenses, repairs, and miscellaneous costs.
      </Typography>
      <Typography variant="caption" color="text.disabled" sx={{ mt: 2, display: "block" }}>
        Coming soon - ready for implementation
      </Typography>
    </Paper>
  );
}
