"use client";

import React from "react";
import { Box, Typography, Paper } from "@mui/material";
import { AttachMoney } from "@mui/icons-material";

export default function LeaseExpenseTab({ driverNumber, startDate, endDate }) {
  return (
    <Paper sx={{ p: 6, textAlign: "center" }}>
      <AttachMoney sx={{ fontSize: 80, color: "text.disabled", mb: 2 }} />
      <Typography variant="h6" color="text.secondary" gutterBottom>
        Lease Expense Tracking
      </Typography>
      <Typography variant="body2" color="text.secondary">
        This feature will show lease expenses when the driver operates cabs owned by
        others.
      </Typography>
      <Typography variant="caption" color="text.disabled" sx={{ mt: 2, display: "block" }}>
        Coming soon - ready for implementation
      </Typography>
    </Paper>
  );
}
