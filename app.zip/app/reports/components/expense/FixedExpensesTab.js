"use client";

import React from "react";
import { Box, Typography, Paper } from "@mui/material";
import { Autorenew } from "@mui/icons-material";

export default function FixedExpensesTab({ driverNumber, startDate, endDate }) {
  return (
    <Paper sx={{ p: 6, textAlign: "center" }}>
      <Autorenew sx={{ fontSize: 80, color: "text.disabled", mb: 2 }} />
      <Typography variant="h6" color="text.secondary" gutterBottom>
        Fixed Expenses Tracking
      </Typography>
      <Typography variant="body2" color="text.secondary">
        This feature will display recurring expenses like insurance, maintenance, and
        subscriptions.
      </Typography>
      <Typography variant="caption" color="text.disabled" sx={{ mt: 2, display: "block" }}>
        Coming soon - ready for implementation
      </Typography>
    </Paper>
  );
}
