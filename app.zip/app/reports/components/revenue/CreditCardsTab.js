"use client";

import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TableFooter,
  Button,
  CircularProgress,
  Alert,
  Grid,
  Card,
  CardContent,
  Chip,
  Tooltip,
} from "@mui/material";
import {
  Download,
  CreditCard,
  AttachMoney,
  CheckCircle,
  Schedule,
  Cancel,
  Receipt,
  AccountBalance,
} from "@mui/icons-material";
import { format } from "date-fns";
import axios from "axios";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080/api";

export default function CreditCardsTab({ driverNumber, startDate, endDate }) {
  const [reportData, setReportData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (driverNumber && startDate && endDate) {
      fetchCreditCardRevenueReport();
    }
  }, [driverNumber, startDate, endDate]);

  const fetchCreditCardRevenueReport = async () => {
    setLoading(true);
    setError(null);

    try {
      const token = localStorage.getItem("token");
      const formattedStartDate = format(startDate, "yyyy-MM-dd");
      const formattedEndDate = format(endDate, "yyyy-MM-dd");

      const response = await axios.get(`${API_BASE_URL}/reports/credit-card-revenue`, {
        params: {
          driverNumber: driverNumber,
          startDate: formattedStartDate,
          endDate: formattedEndDate,
        },
        headers: { Authorization: `Bearer ${token}` },
      });

      setReportData(response.data);
    } catch (err) {
      console.error("Error fetching credit card revenue report:", err);
      setError(err.response?.data?.message || "Failed to fetch credit card revenue report");
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadCSV = () => {
    if (!reportData || !reportData.transactionItems) return;

    const headers = [
      "Date",
      "Time",
      "Auth Code",
      "Terminal ID",
      "Merchant ID",
      "Batch #",
      "Card Type",
      "Last 4",
      "Cab",
      "Job ID",
      "Amount",
      "Tip",
      "Total",
      "Fee",
      "Net",
      "Status",
      "Settled",
      "Settlement Date",
      "Receipt #",
    ];

    const rows = reportData.transactionItems.map((item) => [
      item.transactionDate,
      item.transactionTime || "",
      item.authorizationCode,
      item.terminalId,
      item.merchantId,
      item.batchNumber || "",
      item.cardType || "",
      item.cardLastFour || "",
      item.cabNumber || "",
      item.jobId || "",
      item.amount?.toFixed(2) || "0.00",
      item.tipAmount?.toFixed(2) || "0.00",
      item.totalAmount?.toFixed(2) || "0.00",
      item.processingFee?.toFixed(2) || "0.00",
      item.netAmount?.toFixed(2) || "0.00",
      item.transactionStatus,
      item.isSettled ? "Yes" : "No",
      item.settlementDate || "",
      item.receiptNumber || "",
    ]);

    // Add summary rows
    rows.push([]);
    rows.push([
      "TOTALS",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      reportData.totalAmount?.toFixed(2) || "0.00",
      reportData.totalTipAmount?.toFixed(2) || "0.00",
      reportData.grandTotal?.toFixed(2) || "0.00",
      reportData.totalProcessingFees?.toFixed(2) || "0.00",
      reportData.netTotal?.toFixed(2) || "0.00",
      "",
      "",
      "",
      "",
    ]);

    rows.push([]);
    rows.push([
      "Settlement Summary:",
      `Settled: ${reportData.settledTransactions} ($${reportData.settledAmount?.toFixed(2)})`,
      `Unsettled: ${reportData.unsettledTransactions} ($${reportData.unsettledAmount?.toFixed(2)})`,
    ]);

    if (reportData.refundedTransactions > 0) {
      rows.push([
        "Refunds:",
        `${reportData.refundedTransactions} transactions`,
        `$${reportData.totalRefundedAmount?.toFixed(2)}`,
      ]);
    }

    const csvContent = [
      headers.join(","),
      ...rows.map((row) => row.map(cell => `"${cell}"`).join(",")),
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `credit-card-revenue-${driverNumber}-${format(startDate, "yyyy-MM-dd")}-to-${format(endDate, "yyyy-MM-dd")}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const getCardIcon = (cardType) => {
    return <CreditCard />;
  };

  const getStatusChip = (status) => {
    const statusColors = {
      SETTLED: "success",
      PENDING: "warning",
      DECLINED: "error",
      REFUNDED: "default",
      DISPUTED: "error",
    };
    return (
      <Chip
        label={status}
        size="small"
        color={statusColors[status] || "default"}
      />
    );
  };

  if (loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", py: 8 }}>
        <CircularProgress />
        <Typography sx={{ ml: 2 }}>Loading credit card revenue report...</Typography>
      </Box>
    );
  }

  if (error) {
    return (
      <Alert severity="error" sx={{ mb: 2 }}>
        {error}
      </Alert>
    );
  }

  if (!reportData || !reportData.transactionItems || reportData.transactionItems.length === 0) {
    return (
      <Paper sx={{ p: 6, textAlign: "center" }}>
        <CreditCard sx={{ fontSize: 80, color: "text.disabled", mb: 2 }} />
        <Typography variant="h6" color="text.secondary" gutterBottom>
          No Credit Card Transactions Found
        </Typography>
        <Typography variant="body2" color="text.secondary">
          No credit card transactions for this driver in the selected date range.
        </Typography>
      </Paper>
    );
  }

  return (
    <Box>
      {/* Summary Cards Row 1 */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={2.4}>
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="body2" gutterBottom>
                Total Transactions
              </Typography>
              <Typography variant="h4" sx={{ fontWeight: 600 }}>
                {reportData.totalTransactions || 0}
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={2.4}>
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="body2" gutterBottom>
                Total Amount
              </Typography>
              <Typography variant="h4" sx={{ fontWeight: 600, color: "primary.main" }}>
                ${reportData.totalAmount?.toFixed(2) || "0.00"}
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={2.4}>
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="body2" gutterBottom>
                Total Tips
              </Typography>
              <Typography variant="h4" sx={{ fontWeight: 600, color: "success.main" }}>
                ${reportData.totalTipAmount?.toFixed(2) || "0.00"}
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={2.4}>
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="body2" gutterBottom>
                Processing Fees
              </Typography>
              <Typography variant="h4" sx={{ fontWeight: 600, color: "error.main" }}>
                ${reportData.totalProcessingFees?.toFixed(2) || "0.00"}
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={2.4}>
          <Card sx={{ bgcolor: "primary.main", color: "white" }}>
            <CardContent>
              <Typography sx={{ opacity: 0.9 }} variant="body2" gutterBottom>
                Net Total
              </Typography>
              <Typography variant="h4" sx={{ fontWeight: 600 }}>
                ${reportData.netTotal?.toFixed(2) || "0.00"}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Settlement & Status Cards Row 2 */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={4}>
          <Card sx={{ bgcolor: "success.light", color: "success.dark" }}>
            <CardContent>
              <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                <CheckCircle />
                <Box>
                  <Typography variant="body2" sx={{ opacity: 0.9 }}>
                    Settled
                  </Typography>
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>
                    {reportData.settledTransactions} txns - ${reportData.settledAmount?.toFixed(2) || "0.00"}
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={4}>
          <Card sx={{ bgcolor: "warning.light", color: "warning.dark" }}>
            <CardContent>
              <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                <Schedule />
                <Box>
                  <Typography variant="body2" sx={{ opacity: 0.9 }}>
                    Unsettled
                  </Typography>
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>
                    {reportData.unsettledTransactions} txns - ${reportData.unsettledAmount?.toFixed(2) || "0.00"}
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {reportData.refundedTransactions > 0 && (
          <Grid item xs={12} sm={6} md={4}>
            <Card sx={{ bgcolor: "error.light", color: "error.dark" }}>
              <CardContent>
                <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                  <Cancel />
                  <Box>
                    <Typography variant="body2" sx={{ opacity: 0.9 }}>
                      Refunded
                    </Typography>
                    <Typography variant="h6" sx={{ fontWeight: 600 }}>
                      {reportData.refundedTransactions} txns - ${reportData.totalRefundedAmount?.toFixed(2) || "0.00"}
                    </Typography>
                  </Box>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        )}
      </Grid>

      {/* Card Type Breakdown */}
      {reportData.cardTypeBreakdown && Object.keys(reportData.cardTypeBreakdown).length > 0 && (
        <Grid container spacing={2} sx={{ mb: 3 }}>
          {Object.entries(reportData.cardTypeBreakdown).map(([cardType, stats]) => (
            <Grid item xs={6} sm={4} md={3} key={cardType}>
              <Card variant="outlined">
                <CardContent sx={{ textAlign: "center" }}>
                  <CreditCard sx={{ fontSize: 32, color: "primary.main", mb: 1 }} />
                  <Typography variant="body2" color="text.secondary">
                    {cardType}
                  </Typography>
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>
                    {stats.count} txns
                  </Typography>
                  <Typography variant="body2" color="primary.main">
                    ${stats.totalAmount?.toFixed(2) || "0.00"}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}

      {/* Detailed Table */}
      <Paper>
        <Box
          sx={{
            p: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            borderBottom: 1,
            borderColor: "divider",
          }}
        >
          <Box>
            <Typography variant="h6" sx={{ fontWeight: 600 }}>
              Credit Card Transaction Details
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Transactions for {reportData.driverName} ({reportData.driverNumber})
            </Typography>
          </Box>
          <Button
            variant="outlined"
            startIcon={<Download />}
            onClick={handleDownloadCSV}
          >
            Export CSV
          </Button>
        </Box>

        <TableContainer sx={{ maxHeight: 600 }}>
          <Table stickyHeader>
            <TableHead>
              <TableRow>
                <TableCell>Date/Time</TableCell>
                <TableCell>Auth Code</TableCell>
                <TableCell>Terminal</TableCell>
                <TableCell>Card</TableCell>
                <TableCell>Cab/Job</TableCell>
                <TableCell align="right">Amount</TableCell>
                <TableCell align="right">Tip</TableCell>
                <TableCell align="right">Total</TableCell>
                <TableCell align="right">Fee</TableCell>
                <TableCell align="right">Net</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Settlement</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {reportData.transactionItems.map((item, index) => (
                <TableRow key={index} hover>
                  <TableCell>
                    <Box>
                      <Typography variant="body2" sx={{ fontWeight: 500 }}>
                        {item.transactionDate}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        {item.transactionTime || "N/A"}
                      </Typography>
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Tooltip title={`Merchant: ${item.merchantId}`}>
                      <Typography variant="body2" sx={{ fontFamily: "monospace" }}>
                        {item.authorizationCode}
                      </Typography>
                    </Tooltip>
                  </TableCell>
                  <TableCell>
                    <Typography variant="caption">{item.terminalId}</Typography>
                  </TableCell>
                  <TableCell>
                    <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                      {getCardIcon(item.cardType)}
                      <Box>
                        <Typography variant="body2">{item.cardType || "N/A"}</Typography>
                        {item.cardLastFour && (
                          <Typography variant="caption" color="text.secondary">
                            ****{item.cardLastFour}
                          </Typography>
                        )}
                      </Box>
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Box>
                      <Typography variant="body2">{item.cabNumber || "N/A"}</Typography>
                      {item.jobId && (
                        <Typography variant="caption" color="text.secondary">
                          Job: {item.jobId}
                        </Typography>
                      )}
                    </Box>
                  </TableCell>
                  <TableCell align="right" sx={{ fontWeight: 500 }}>
                    ${item.amount?.toFixed(2) || "0.00"}
                  </TableCell>
                  <TableCell align="right" sx={{ color: "success.main" }}>
                    ${item.tipAmount?.toFixed(2) || "0.00"}
                  </TableCell>
                  <TableCell align="right" sx={{ fontWeight: 600 }}>
                    ${item.totalAmount?.toFixed(2) || "0.00"}
                  </TableCell>
                  <TableCell align="right" sx={{ color: "error.main" }}>
                    ${item.processingFee?.toFixed(2) || "0.00"}
                  </TableCell>
                  <TableCell align="right" sx={{ fontWeight: 600, color: "primary.main" }}>
                    ${item.netAmount?.toFixed(2) || "0.00"}
                  </TableCell>
                  <TableCell>
                    {getStatusChip(item.transactionStatus)}
                    {item.isRefunded && (
                      <Chip
                        label="Refunded"
                        size="small"
                        color="error"
                        sx={{ ml: 0.5 }}
                      />
                    )}
                  </TableCell>
                  <TableCell>
                    <Box>
                      <Chip
                        icon={item.isSettled ? <CheckCircle /> : <Schedule />}
                        label={item.isSettled ? "Settled" : "Pending"}
                        size="small"
                        color={item.isSettled ? "success" : "warning"}
                      />
                      {item.settlementDate && (
                        <Typography variant="caption" sx={{ display: "block", mt: 0.5 }}>
                          {item.settlementDate}
                        </Typography>
                      )}
                    </Box>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
            <TableFooter>
              <TableRow>
                <TableCell colSpan={5} align="right" sx={{ fontWeight: 600 }}>
                  GRAND TOTAL
                </TableCell>
                <TableCell align="right" sx={{ fontWeight: 600 }}>
                  ${reportData.totalAmount?.toFixed(2) || "0.00"}
                </TableCell>
                <TableCell align="right" sx={{ fontWeight: 600 }}>
                  ${reportData.totalTipAmount?.toFixed(2) || "0.00"}
                </TableCell>
                <TableCell align="right" sx={{ fontWeight: 600 }}>
                  ${reportData.grandTotal?.toFixed(2) || "0.00"}
                </TableCell>
                <TableCell align="right" sx={{ fontWeight: 600 }}>
                  ${reportData.totalProcessingFees?.toFixed(2) || "0.00"}
                </TableCell>
                <TableCell
                  align="right"
                  sx={{ fontWeight: 700, color: "primary.main", fontSize: 18 }}
                >
                  ${reportData.netTotal?.toFixed(2) || "0.00"}
                </TableCell>
                <TableCell colSpan={2}></TableCell>
              </TableRow>
            </TableFooter>
          </Table>
        </TableContainer>
      </Paper>
    </Box>
  );
}