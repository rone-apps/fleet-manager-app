"use client";

import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TableFooter,
  Button,
  CircularProgress,
  Alert,
  Grid,
  Card,
  CardContent,
  Chip,
} from "@mui/material";
import {
  Download,
  AttachMoney,
  DirectionsCar,
  LocalShipping,
  TrendingUp,
} from "@mui/icons-material";
import { format } from "date-fns";
import axios from "axios";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080/api";

export default function LeaseRevenueTab({ driverNumber, startDate, endDate }) {
  const [reportData, setReportData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (driverNumber && startDate && endDate) {
      fetchLeaseRevenueReport();
    }
  }, [driverNumber, startDate, endDate]);

  const fetchLeaseRevenueReport = async () => {
    setLoading(true);
    setError(null);

    try {
      const token = localStorage.getItem("token");
      const formattedStartDate = format(startDate, "yyyy-MM-dd");
      const formattedEndDate = format(endDate, "yyyy-MM-dd");

      const response = await axios.get(`${API_BASE_URL}/reports/lease-revenue`, {
        params: {
          ownerDriverNumber: driverNumber,
          startDate: formattedStartDate,
          endDate: formattedEndDate,
        },
        headers: { Authorization: `Bearer ${token}` },
      });

      setReportData(response.data);
    } catch (err) {
      console.error("Error fetching lease revenue report:", err);
      setError(err.response?.data?.message || "Failed to fetch lease revenue report");
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadCSV = () => {
    if (!reportData || !reportData.leaseItems) return;

    // Create CSV content
    const headers = [
      "Date",
      "Driver",
      "Driver Number",
      "Cab",
      "Shift Type",
      "Hours",
      "Base Rate",
      "Miles",
      "Mileage Rate",
      "Mileage Lease",
      "Total Lease",
    ];

    const rows = reportData.leaseItems.map((item) => [
      format(new Date(item.shiftDate), "yyyy-MM-dd"),
      item.driverName || item.driverNumber,
      item.driverNumber,
      item.cabNumber,
      item.shiftType,
      item.totalHours?.toFixed(2) || "0.00",
      item.baseRate?.toFixed(2) || "0.00",
      item.miles?.toFixed(2) || "0.00",
      item.mileageRate?.toFixed(4) || "0.0000",
      item.mileageLease?.toFixed(2) || "0.00",
      item.totalLease?.toFixed(2) || "0.00",
    ]);

    // Add summary row
    rows.push([]);
    rows.push([
      "TOTALS",
      "",
      "",
      "",
      "",
      "",
      reportData.totalBaseRates?.toFixed(2) || "0.00",
      reportData.totalMiles?.toFixed(2) || "0.00",
      "",
      reportData.totalMileageLease?.toFixed(2) || "0.00",
      reportData.grandTotalLease?.toFixed(2) || "0.00",
    ]);

    const csvContent = [
      headers.join(","),
      ...rows.map((row) => row.join(",")),
    ].join("\n");

    // Download file
    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `lease-revenue-${driverNumber}-${format(
      startDate,
      "yyyy-MM-dd"
    )}-to-${format(endDate, "yyyy-MM-dd")}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", py: 8 }}>
        <CircularProgress />
        <Typography sx={{ ml: 2 }}>Loading lease revenue report...</Typography>
      </Box>
    );
  }

  if (error) {
    return (
      <Alert severity="error" sx={{ mb: 2 }}>
        {error}
      </Alert>
    );
  }

  if (!reportData || reportData.leaseItems.length === 0) {
    return (
      <Paper sx={{ p: 6, textAlign: "center" }}>
        <AttachMoney sx={{ fontSize: 80, color: "text.disabled", mb: 2 }} />
        <Typography variant="h6" color="text.secondary" gutterBottom>
          No Lease Revenue Data Found
        </Typography>
        <Typography variant="body2" color="text.secondary">
          This driver may not own any cabs or no other drivers drove their cabs during
          this period.
        </Typography>
      </Paper>
    );
  }

  return (
    <Box>
      {/* Summary Cards */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="body2" gutterBottom>
                Total Shifts
              </Typography>
              <Typography variant="h4" sx={{ fontWeight: 600 }}>
                {reportData.totalShifts || 0}
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="body2" gutterBottom>
                Total Base Rates
              </Typography>
              <Typography variant="h4" sx={{ fontWeight: 600, color: "primary.main" }}>
                ${reportData.totalBaseRates?.toFixed(2) || "0.00"}
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="body2" gutterBottom>
                Total Miles
              </Typography>
              <Typography variant="h4" sx={{ fontWeight: 600 }}>
                {reportData.totalMiles?.toFixed(2) || "0.00"}
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ bgcolor: "primary.main", color: "white" }}>
            <CardContent>
              <Typography sx={{ opacity: 0.9 }} variant="body2" gutterBottom>
                Grand Total
              </Typography>
              <Typography variant="h4" sx={{ fontWeight: 600 }}>
                ${reportData.grandTotalLease?.toFixed(2) || "0.00"}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Detailed Table */}
      <Paper>
        <Box
          sx={{
            p: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            borderBottom: 1,
            borderColor: "divider",
          }}
        >
          <Box>
            <Typography variant="h6" sx={{ fontWeight: 600 }}>
              Lease Revenue Details
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Showing lease owed to {reportData.ownerDriverName} (
              {reportData.ownerDriverNumber})
            </Typography>
          </Box>
          <Button
            variant="outlined"
            startIcon={<Download />}
            onClick={handleDownloadCSV}
          >
            Export CSV
          </Button>
        </Box>

        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Date</TableCell>
                <TableCell>Driver</TableCell>
                <TableCell>Cab</TableCell>
                <TableCell>Shift</TableCell>
                <TableCell align="right">Hours</TableCell>
                <TableCell align="right">Base Rate</TableCell>
                <TableCell align="right">Miles</TableCell>
                <TableCell align="right">Mileage Rate</TableCell>
                <TableCell align="right">Mileage Lease</TableCell>
                <TableCell align="right">Total Lease</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {reportData.leaseItems.map((item, index) => (
                <TableRow key={index} hover>
                  <TableCell>{format(new Date(item.shiftDate), "MMM dd, yyyy")}</TableCell>
                  <TableCell>
                    <Box>
                      <Typography variant="body2" sx={{ fontWeight: 500 }}>
                        {item.driverName}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        {item.driverNumber}
                      </Typography>
                    </Box>
                  </TableCell>
                  <TableCell>{item.cabNumber}</TableCell>
                  <TableCell>
                    <Chip
                      label={item.shiftType}
                      size="small"
                      color={item.shiftType === "DAY" ? "warning" : "info"}
                    />
                  </TableCell>
                  <TableCell align="right">
                    {item.totalHours?.toFixed(2) || "0.00"}
                  </TableCell>
                  <TableCell align="right" sx={{ fontWeight: 500 }}>
                    ${item.baseRate?.toFixed(2) || "0.00"}
                  </TableCell>
                  <TableCell align="right">
                    {item.miles?.toFixed(2) || "0.00"}
                  </TableCell>
                  <TableCell align="right">
                    ${item.mileageRate?.toFixed(4) || "0.0000"}
                  </TableCell>
                  <TableCell align="right">
                    ${item.mileageLease?.toFixed(2) || "0.00"}
                  </TableCell>
                  <TableCell align="right" sx={{ fontWeight: 600, color: "primary.main" }}>
                    ${item.totalLease?.toFixed(2) || "0.00"}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
            <TableFooter>
              <TableRow>
                <TableCell colSpan={5} align="right" sx={{ fontWeight: 600 }}>
                  GRAND TOTAL
                </TableCell>
                <TableCell align="right" sx={{ fontWeight: 600 }}>
                  ${reportData.totalBaseRates?.toFixed(2) || "0.00"}
                </TableCell>
                <TableCell align="right" sx={{ fontWeight: 600 }}>
                  {reportData.totalMiles?.toFixed(2) || "0.00"}
                </TableCell>
                <TableCell></TableCell>
                <TableCell align="right" sx={{ fontWeight: 600 }}>
                  ${reportData.totalMileageLease?.toFixed(2) || "0.00"}
                </TableCell>
                <TableCell
                  align="right"
                  sx={{ fontWeight: 700, color: "primary.main", fontSize: 18 }}
                >
                  ${reportData.grandTotalLease?.toFixed(2) || "0.00"}
                </TableCell>
              </TableRow>
            </TableFooter>
          </Table>
        </TableContainer>
      </Paper>
    </Box>
  );
}
