"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import GlobalNav from "../components/GlobalNav";
import {
  Box,
  Container,
  Typography,
  Button,
  Paper,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextField,
  Tabs,
  Tab,
  Card,
  CardContent,
} from "@mui/material";
import {
  Assessment,
  CalendarToday,
  Download,
  TrendingUp,
  TrendingDown,
} from "@mui/icons-material";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import axios from "axios";

// Import tab components
import RevenueTab from "./components/RevenueTab";
import ExpenseTab from "./components/ExpenseTab";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080/api";

export default function ReportsPage() {
  const router = useRouter();
  const [drivers, setDrivers] = useState([]);
  const [selectedDriver, setSelectedDriver] = useState("");
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [activeTab, setActiveTab] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      router.push("/signin");
      return;
    }
    fetchDrivers();
  }, []);

  const fetchDrivers = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await axios.get(`${API_BASE_URL}/drivers`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      // Filter only owner drivers
      const ownerDrivers = response.data.filter((driver) => driver.isOwner === true);
      setDrivers(ownerDrivers);
    } catch (error) {
      console.error("Error fetching drivers:", error);
      setError("Failed to fetch drivers");
    }
  };

  const handleGenerateReport = () => {
    if (!selectedDriver || !startDate || !endDate) {
      setError("Please select a driver and date range");
      return;
    }
    setError("");
    setLoading(true);
    // Trigger report generation in child components
    setTimeout(() => setLoading(false), 500);
  };

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const isReportReady = selectedDriver && startDate && endDate;

  return (
    <Box sx={{ display: "flex", minHeight: "100vh", bgcolor: "#f5f5f5" }}>
      <GlobalNav />
      <Box component="main" sx={{ flexGrow: 1, p: 3, mt: 8 }}>
        <Container maxWidth="xl">
          {/* Header */}
          <Box sx={{ mb: 4 }}>
            <Typography variant="h4" sx={{ fontWeight: 600, mb: 1 }}>
              <Assessment sx={{ mr: 1, verticalAlign: "middle", fontSize: 32 }} />
              Financial Reports
            </Typography>
            <Typography variant="body1" color="text.secondary">
              Generate detailed revenue and expense reports for drivers
            </Typography>
          </Box>

          {/* Filter Controls */}
          <Paper sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" sx={{ mb: 3, fontWeight: 600 }}>
              Report Parameters
            </Typography>

            {error && (
              <Box sx={{ mb: 2 }}>
                <Typography color="error">{error}</Typography>
              </Box>
            )}

            <Grid container spacing={2}>
              {/* Driver Selection */}
              <Grid item xs={12} md={3}>
                <FormControl fullWidth>
                  <InputLabel>Select Driver</InputLabel>
                  <Select
                    value={selectedDriver}
                    label="Select Driver"
                    onChange={(e) => setSelectedDriver(e.target.value)}
                  >
                    <MenuItem value="">
                      <em>Choose driver...</em>
                    </MenuItem>
                    {drivers.map((driver) => (
                      <MenuItem key={driver.id} value={driver.driverNumber}>
                        {driver.firstName} {driver.lastName} ({driver.driverNumber})
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>

              {/* Date Range */}
              <Grid item xs={12} md={3}>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DatePicker
                    label="Start Date"
                    value={startDate}
                    onChange={(newValue) => setStartDate(newValue)}
                    renderInput={(params) => <TextField {...params} fullWidth />}
                    slotProps={{ textField: { fullWidth: true } }}
                  />
                </LocalizationProvider>
              </Grid>

              <Grid item xs={12} md={3}>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DatePicker
                    label="End Date"
                    value={endDate}
                    onChange={(newValue) => setEndDate(newValue)}
                    renderInput={(params) => <TextField {...params} fullWidth />}
                    slotProps={{ textField: { fullWidth: true } }}
                  />
                </LocalizationProvider>
              </Grid>

              {/* Generate Button */}
              <Grid item xs={12} md={3}>
                <Button
                  variant="contained"
                  fullWidth
                  onClick={handleGenerateReport}
                  disabled={!isReportReady || loading}
                  startIcon={<Assessment />}
                  sx={{ height: 56 }}
                >
                  {loading ? "Loading..." : "Generate Report"}
                </Button>
              </Grid>
            </Grid>
          </Paper>

          {/* Report Tabs */}
          {isReportReady && (
            <Paper sx={{ mb: 3 }}>
              <Tabs
                value={activeTab}
                onChange={handleTabChange}
                sx={{ borderBottom: 1, borderColor: "divider" }}
              >
                <Tab
                  icon={<TrendingUp />}
                  iconPosition="start"
                  label="Revenue"
                  sx={{ minHeight: 64 }}
                />
                <Tab
                  icon={<TrendingDown />}
                  iconPosition="start"
                  label="Expenses"
                  sx={{ minHeight: 64 }}
                />
              </Tabs>

              <Box sx={{ p: 3 }}>
                {activeTab === 0 && (
                  <RevenueTab
                    driverNumber={selectedDriver}
                    startDate={startDate}
                    endDate={endDate}
                  />
                )}
                {activeTab === 1 && (
                  <ExpenseTab
                    driverNumber={selectedDriver}
                    startDate={startDate}
                    endDate={endDate}
                  />
                )}
              </Box>
            </Paper>
          )}

          {/* Empty State */}
          {!isReportReady && (
            <Paper sx={{ p: 6, textAlign: "center" }}>
              <Assessment sx={{ fontSize: 80, color: "text.disabled", mb: 2 }} />
              <Typography variant="h6" color="text.secondary" gutterBottom>
                Select Parameters to Generate Reports
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Choose a driver and date range to view financial reports
              </Typography>
            </Paper>
          )}
        </Container>
      </Box>
    </Box>
  );
}
